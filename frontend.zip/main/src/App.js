import React from 'react';
import Header from './Component/header';
import Main from './Component/main';
import Safe from './Component/Safe';
import SoWhatOthers from './Component/SoWhatOthers';
import OnlineReservations from './Component/OnlineReservations';
import Footer from './Component/footer';
import WeatherComponent from './Component/WeatherComponent';
import ContactForm from './Component/ContactForm';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './Component/style.css';
import MapComponent from './Component/MapComponent';

const App = () => {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={
          <>
            <div className="App">
            <WeatherComponent />
            </div>
            <div>
            <Main />
            <Safe />
            <SoWhatOthers />
            <OnlineReservations />
           <MapComponent />
           </div>
           </>
        } exact />
        <Route path="/contact" element={<ContactForm />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
};

export default App;
