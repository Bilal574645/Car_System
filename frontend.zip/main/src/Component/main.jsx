import React from 'react';
import img5 from './BSSE-F-21-A-Assig-PSD-Groups/car(container).gif';
import img6 from './projects-assets/car2.png';
import img7 from './projects-assets/car3.png';
import img8 from './projects-assets/car4.png';
import img9 from './projects-assets/car5.png';
// import img10 from './projects-assets/car6.png';

function Main() {
  return (
    <div className='Mainclass'>
      <img id="mainpic" className="first" src={img5} alt="" />

      {/* <!-- start of car types --> */}
      <div className="cartypes">
        <div className="car" id="towncar">
          <div className="seats"><p>3 Passenger</p></div>
          <div className="type"><p>Town Car</p></div>
          <img src={img6} className="seatsPassenger" alt="" />
        </div>

        <div className="car" id="limousine">
          <div className="seats"><p>10 Passenger</p></div>
          <div className="type"><p>Limousine</p></div>
          <img src={img7} className="typeLimosine" alt="" />
        </div>

        <div className="car" id="executive">
          <div className="seats"><p>13 Passenger</p></div>
          <div className="type"><p>Executive Car</p></div>
          <img src={img8} className="typeExecutive" alt="" />
        </div>

        <div className="car" id="minibus">
          <div className="seats"><p>29 Passenger</p></div>
          <div className="type"><p>Mini Bus</p></div>
          <img src={img9} className="typeMini" alt="" />
        </div>
      </div>

      {/* <!-- carService-container --> */}
      <div className="carService-container">
        <div className="carService-containerC1">
          <div className="item1">
            <h2>DFW Corporate Car Service</h2>
          </div>
          <div className="item3">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni, odit dolor illo earum officia quibusdam perspiciatis commodi ipsum sint deleniti, consequatur maiores ut praesentium sed incidunt repellendus inventore sunt corporis necessitatibus esse atque ab. Quod minima provident fuga recusandae, nisi cumque facilis autem ex culpa assumenda sed officia! Nam aut incidunt laborum praesentium reiciendis commodi consequatur aspernatur quas id vitae obcaecati neque animi repudiandae dolorem earum veniam temporibus sapiente explicabo, aliquid ipsam distinctio libero consequuntur sit eveniet. Aperiam tempora ratione error mollitia. Hic officia similique ipsum dolores et doloremque tempore.</p>
          </div>
          <div className="item5">
            <button className="itembutton"><h5>Make a Reservation</h5></button>
          </div>
        </div>
        <div className="carService-containerC2">
          <div className="item2-container">
            <div className="item2one">
              <h4 className="BoxShutter">Shuttle and Private Service To</h4>
              <p>Ames Lake, Ballard, Capitol Hill, Edmonds, Ficrest, Green Lake, Juanita, Laurelhurst</p>
            </div>
          </div>
          <div className="item4">
            <h3 className="PlusPrivate">Plus Private Service to</h3>
            <ul className="Pluslist">
              <li>Dallas/Fort Worth International Airport</li>
              <li>O'Hare International Airport</li>
              <li>Dallas/Fort Worth International Airport</li>
              <li>O'Hare International Airport</li>
              <li>Dallas/Fort Worth International Airport</li>
            </ul>
          </div>
        </div>
      </div>

      {/* <!-- End of DFW div--> */}
    </div>
  );
}

export default Main;
