import React from 'react';
import img10 from './projects-assets/logo1.png';
import img11 from './projects-assets/video1.png';
import img12 from './projects-assets/videologo1.png';
function Safe(){
    return(
        <div className="GoSafe">
    <div className="GoSafeC1">
   <div className="GoSafeC1kR1">
    <h3 style={{color: '#d71a21'}}>Go Safe, Go Green with DFW Corporate Car Service</h3>
   </div>
   <div className="GoSafeC1kR2">
   <div className="GoSafeC1kR2R1">
    <img src={img10} alt=""/>
   </div>
   <div className="GoSafeC1kR2R2">  <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, et tempora earum porro eius neque eligendi odit vero nisi beatae cum? Temporibus adipisci suscipit veniam quam vel expedita debitis quos nemo sequi nam. Iste blanditiis necessitatibus asperiores, est eaque corrupti expedita. Odio aut fugiat eum.</p></div>
   <div className="GoSafeC1kR2R3">
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusantium, dicta! Explicabo ducimus labore rerum iusto nemo, nesciunt reiciendis totam accusantium, cupiditate neque repellat ea similique! Lorem ipsum dolor sit amet consectetur, adipisicing elit. A, nobis?
   </div>

   </div>

    </div>
    <div className="GoSafeC2">
        <img  className="Videoimage" src={img11} alt=""/>
        <img className="image-overlay" src={img12} alt=""/>
    </div>
</div>
    )
}
export default Safe;