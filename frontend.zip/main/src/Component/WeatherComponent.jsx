// src/components/WeatherComponent.js
import React, { useState, useEffect } from 'react';
import { getWeatherByCity, getWeatherByCoords } from './services/weatherService';

const WeatherComponent = () => {
  const [weatherData, setWeatherData] = useState(null);
  const [searchCity, setSearchCity] = useState('');
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchWeatherByLocation = async () => {
      try {
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            const { latitude, longitude } = position.coords;
            const data = await getWeatherByCoords(latitude, longitude);
            setWeatherData(data);
          },
          (error) => {
            console.error('Error getting location', error);
            setError('Error getting location');
          }
        );
      } catch (error) {
        console.error('Error getting weather data', error);
        setError('Error getting weather data');
      }
    };

    fetchWeatherByLocation();
  }, []);

  const fetchWeatherByCity = async () => {
    try {
      const data = await getWeatherByCity(searchCity);
      setWeatherData(data);
    } catch (error) {
      console.error('Error getting weather data', error);
      setError('Error getting weather data');
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchCity.trim() !== '') {
      fetchWeatherByCity();
    }
  };

  return (
    <div className='apii'>
      {error && <p>{error}</p>}
      {weatherData && (
        <div>
          <center>
            <h2>{weatherData.name}</h2>
            <p>Temperature: {weatherData.main.temp}°C</p>
            <p>Humidity: {weatherData.main.humidity}%</p>
            <p>Weather: {weatherData.weather[0].description}</p>
            <p>Wind Speed: {weatherData.wind.speed} m/s</p>
            <p>Pressure: {weatherData.main.pressure} hPa</p>
          </center>
        </div>
      )}
      <form onSubmit={handleSearch}>
        <input
          type="text"
          placeholder="Enter city name"
          value={searchCity}
          onChange={(e) => setSearchCity(e.target.value)}
        />
        <button type="submit">Search</button>
      </form>
    </div>
  );
};

export default WeatherComponent;
