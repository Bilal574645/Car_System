import React from 'react'
import img17 from './projects-assets/car4.png';
import img18 from './projects-assets/companylogo1.png';
import img2 from './BSSE-F-21-A-Assig-PSD-Groups/fblogo.gif';
import img3 from './BSSE-F-21-A-Assig-PSD-Groups/gllogo.gif';
import img4 from './BSSE-F-21-A-Assig-PSD-Groups/twtlogo.gif';

export default function Footer() {
  return (
    <div>
        <div className="footer">


<div className="footerR1">

    <div >
        <img className="footerR1Item1" src={img17} alt=""/>
    </div>

    <div className="footerR1Item2">
        Reserve a Car service Today and Make Your leisure or Busniness Travel Count <br/>
        <span>6827047222</span>
    </div>

    <div className="footerR1Item3">
       <button><h5>Instant Quote & Booking</h5></button>
    </div>
</div>

<hr  className="redcolhr" style={{borderColor:'#d71a21'}}/>

<div className="footer2">
    <div className="footer2Item1">
        <h3 style={{marginBottom: '4%'}}>Contacts Information</h3>
        
        <hr className="redcolhr" width="10%"  style={{borderColor:'#d71a21'}}/>
        <br/>
        
        <h4>6827047222</h4>
        <button>Instant Quote & Booking</button>
        <h4>E-mail Address</h4>
        <h5>info@dfwcorporatecarservice.com</h5>
        <section className="footer2Item1one">
            <div className="logos">
               <ul>
                <li> <div id="fblogo2"><img src={img2} alt=""/></div></li>
               <li><div id="twtlogo2"><img src={img3} alt=""/></div></li>
               <li><div className="gllogo2"><img src={img4} alt=""/></div></li>   
            </ul>
            </div>
            
        </section>
    </div>
    <div className="footer2Item2">
        <title>Services</title>
        
        <ul>
            <div><li><h3>Services</h3></li></div>
            <hr width="10%"  style={{borderColor:'#d71a21'}}/>
            <br/>
            <li>Airport Transportation</li>
            <li>Busniness Travel Transportation</li>
            <li>Special Events and occasions</li>
            <li>Hourly Rate Car Service</li>
        </ul>
    </div>
    <div className="footer2Item3">
        <title>Airport We Service</title>
        <ul>
            <div><li><h3>Airport We Service</h3></li></div>
            <hr width="10%"  style={{borderColor: '#d71a21'}}/>
            <br/>
            <li>Dallas/Fort Worth International Airport</li>
            <li>O'Hare International Airport</li>
            <li>Dallas/Fort Worth International Airport</li>
            <li>O'Hare International Airport</li>
        </ul>
    </div>
    <div className="footer2Item4">
        <title>Active & Proud Member</title>
        
        <div><h3>Active & Proud Member</h3></div>
        <hr width="10%"  style={{borderColor:'#d71a21'}}/>
            <br/>
        <img src={img18} alt=""/>
    </div>
</div>

</div>
         <footer class="last">
        <p>@copyright.dfwcorporatecarservice.com.All right reserved.</p>
    </footer>
    </div>
  )
}

