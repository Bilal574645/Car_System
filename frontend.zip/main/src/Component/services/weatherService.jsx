// src/services/weatherService.js
import axios from 'axios';

const apiKey = process.env.REACT_APP_WEATHER_API_KEY;
const apiUrl = 'https://api.openweathermap.org/data/2.5/weather';

export const getWeatherByCity = async (city) => {
  try {
    const response = await axios.get(apiUrl, {
      params: {
        q: city,
        appid: apiKey,
        units: 'metric', // You can adjust the units as needed
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getWeatherByCoords = async (latitude, longitude) => {
  try {
    const response = await axios.get(apiUrl, {
      params: {
        lat: latitude,
        lon: longitude,
        appid: apiKey,
        units: 'metric', // You can adjust the units as needed
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};
