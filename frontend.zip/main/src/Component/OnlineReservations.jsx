import React from 'react';
import img2 from './BSSE-F-21-A-Assig-PSD-Groups/fblogo.gif';
import img3 from './BSSE-F-21-A-Assig-PSD-Groups/gllogo.gif';
import img4 from './BSSE-F-21-A-Assig-PSD-Groups/twtlogo.gif';
import img13 from './projects-assets/card1.png';
import img14 from './projects-assets/card2.png';
import img15 from './projects-assets/card3.png';
import img16 from './projects-assets/card4.png';
import img17 from './projects-assets/car4.png';
import img18 from './projects-assets/companylogo1.png';



function OnlineReservations(){
    return(
        <div className="OnlineReservations">  
        <div className="OnlineReservationsC1">        
    
            <div className="OnlineReservationsC1Item1">
                <h2 >Shared Ride Car Services in Dallas</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi aperiam laudantium modi praesentium? Iste tempore a excepturi porro quis repellat?</p>
            </div>
    
            <div className="OnlineReservationsC1Item2">
                <h2>Car & Shuttle Services</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi aperiam laudantium modi praesentium? Iste tempore a excepturi porro quis repellat?</p>
            </div>
    
            <div className="OnlineReservationsC1Item3">
                <h2>Charter Limo Services</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi aperiam laudantium modi praesentium? Iste tempore a excepturi porro quis repellat?</p>
            </div>
   
            <div className="OnlineReservationsC1Item4">
                <h2>Minibus Services</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi aperiam laudantium modi praesentium? Iste tempore a excepturi porro quis repellat?</p>
            </div>
    
        </div>
        <div className="OnlineReservationsC2">
    
            <div className="OnlineReservationsC2Item1">
    
               <div className="curvedBorder"> <h3 > Online Reservations</h3></div> 
               
               
              <div className="texth4"><h4>You can book online with a few easy steps or call us.</h4></div>  
                <button className="Onlinebutton">Book Now</button>
            </div>
    
            <div className="OnlineReservationsC2Item2">
                <div className="OnlineReservationsC2Item2Row1">
                    <img src={img13} alt=""/>
                    <img src={img14} alt=""/>
                    <img src={img15} alt=""/>
                    <img  className="hid2" src={img16} alt=""/>
                    
                </div>
               
            </div>
    
        </div>
    
</div>


       
       
    );

}
export default OnlineReservations;