import React from 'react';

function SoWhatOthers(){
   return(
    <div className="SoWhatOthers">
    <div className="SoWhatOthersitem1">
     <h2>So What Others are Saying!</h2>
    </div>
    <div className="SoWhatOthersitem2">
     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam non dolore soluta tempore facere ut amet sed exercitationem quod doloribus vel laudantium eaque eveniet doloremque assumenda architecto beatae libero, placeat similique earum mollitia atque minus. Totam voluptatum nisi eligendi, natus asperiores ut debitis magni fuga, soluta nesciunt error voluptatem possimus?</p>
    </div>
 
 </div>
   )
}

export default SoWhatOthers;