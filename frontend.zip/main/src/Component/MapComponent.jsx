// MapComponent.js
import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from 'react-leaflet';
import L from 'leaflet';   //this libarary provides map 
import 'leaflet/dist/leaflet.css';
import './style.css'; 

const customIcon = new L.Icon({
  iconUrl: 'https://icon.png', 
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

const LocateControl = () => {
  const map = useMapEvents({
    locationfound(e) {
      map.setView(e.latlng, map.getZoom());
    },
  });

  const handleClick = () => {
    map.locate({ setView: true, maxZoom: 120 });
  };

  return (
    <button className="locate-button" onClick={handleClick}>
      Locate Me
    </button>
  );
};

const MapComponent = () => {
  const [location, setLocation] = useState({ lat: 0, lon: 0 });

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setLocation({ lat: latitude, lon: longitude });
      },
      (error) => {
        console.error('Error getting location:', error.message);
      }
    );
  }, []);

  return (
    <MapContainer center={[location.lat, location.lon]} zoom={15} style={{ height: '400px', width: '100%' }}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <Marker position={[location.lat, location.lon]} icon={customIcon}>
        <Popup>Your Location</Popup>
      </Marker>
      <LocateControl />
    </MapContainer>
  );
};

export default MapComponent;
