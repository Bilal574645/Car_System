// ContactForm.js
import { useState, useEffect } from 'react';
import axios from 'axios';
import './style.css';
const ContactForm = () => {
  const [contacts, setContacts] = useState([]);
  const [formData, setFormData] = useState({
    _id: null,
    name: '',
    phoneNumber: '',
    email: '',
    message: '',
  });

  useEffect(() => {
    fetchContacts();
  }, []);

  const fetchContacts = async () => {
    try {
      const response = await axios.get('http://localhost:3001/contacts');
      setContacts(response.data);
    } catch (error) {
      console.error('Error fetching contacts:', error);
    }
  };

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const url = formData._id
      ? `http://localhost:3001/contacts/${formData._id}`
      : 'http://localhost:3001/contacts';
    const method = formData._id ? 'put' : 'post';

    try {
      await axios[method](url, formData);
      fetchContacts();
      setFormData({ _id: null, name: '', phoneNumber: '', email: '', message: '' });
    } catch (error) {
      console.error('Error submitting contact:', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/contacts/${id}`);
      fetchContacts();
    } catch (error) {
      console.error('Error deleting contact:', error);
    }
  };

  const handleEdit = (contact) => {
    setFormData(contact);
  };

  return (
    <div className="contact-form-container">

      <h1>Contact Us</h1>
      <form onSubmit={handleSubmit}>
        <label>Name:</label>
        <input type="text" name="name" value={formData.name} onChange={handleInputChange} required />

        <label>Phone Number:</label>
        <input type="text" name="phoneNumber" value={formData.phoneNumber} onChange={handleInputChange} required />

        <label>Email:</label>
        <input type="email" name="email" value={formData.email} onChange={handleInputChange} required />

        <label>Message:</label>
        <textarea name="message" value={formData.message} onChange={handleInputChange} required />

        <button type="submit">{formData._id ? 'Update' : 'Submit'}</button>
      </form>

      <h2>Contact List</h2>
      <ul className="contact-list">
        {contacts.map((contact) => (
          <li key={contact._id} className="contact-details">
            <div>
              <label>Name:</label>
              <span>{contact.name}</span>
            </div>
            <div>
              <label>Phone Number:</label>
              <span>{contact.phoneNumber}</span>
            </div>
            <div>
              <label>Email:</label>
              <span>{contact.email}</span>
            </div>
            <div>
              <label>Message:</label>
              <span>{contact.message}</span>
            </div>
            <div><button onClick={() => handleEdit(contact)}>Edit</button></div>
            <div><button onClick={() => handleDelete(contact._id)}>Delete</button></div>
            
          </li>
        ))}
        
         

      </ul>
    </div>
  );
};

export default ContactForm;
