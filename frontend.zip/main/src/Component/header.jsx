import React from 'react';
import { Link } from 'react-router-dom';
import img1 from './BSSE-F-21-A-Assig-PSD-Groups/number(header).gif';
import img2 from './BSSE-F-21-A-Assig-PSD-Groups/fblogo.gif';
import img3 from './BSSE-F-21-A-Assig-PSD-Groups/gllogo.gif';
import img4 from './BSSE-F-21-A-Assig-PSD-Groups/twtlogo.gif';

export default function Header() {
  return (
    <>
      <div className="headerNav">
        <header className="header-Container">
          <div>
            <img id="number" src={img1} alt="Call 6827047222" />
          </div>
          <div id="heading">
            <h4>DFW Corporate Car Service</h4>
          </div>
          <div className="socialicons">
            <ul>
              <li>
                <div id="fblogo">
                  <img src={img2} alt="facebook" />
                </div>
              </li>
              <li>
                <div id="gllogo">
                  <img src={img3} alt="google" />
                </div>
              </li>
              <li>
                <div id="twtlogo">
                  <img src={img4} alt="twitter" />
                </div>
              </li>
            </ul>
          </div>
        </header>

        <hr />

        <nav className="nav-Container">
          <ul>
            <li className="nav">
              <h4><a href="">Home</a></h4>
            </li>
            <li className="nav">
              <h4><a href="">Services</a></h4>
            </li>
            <li className="nav">
              <h4><a href="">Services Areas</a></h4>
            </li>
            <li>
              <h4><a href="">Fleet</a></h4>
            </li>
            <li className="hid">
              <h4><a href="">Reservations</a></h4>
            </li>
            <li className="hid">
              <h4><a href="">FAQs</a></h4>
            </li>
            <li className="hid">
              <h4><Link to="/contact">Contact</Link></h4>
            </li>
          </ul>
        </nav>
      </div>
    </>
  );
}

