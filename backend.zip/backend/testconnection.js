

const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://shajia:shajia123@cluster0.we2xidq.mongodb.net/?retryWrites=true&w=majority')
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err));
